AddCSLuaFile()

SWEP.HoldType = "pistol"

if CLIENT then
    SWEP.PrintName = "Grappling Gun"
    SWEP.Category = "Fun Weapons"
    SWEP.Slot = 2
    SWEP.SlotPos = 1
    SWEP.DrawAmmo = false
    SWEP.DrawCrosshair = true
end

SWEP.Base = "weapon_base"
SWEP.Author = "KolyanRublev"
SWEP.Instructions = "LMB: Pull to surface, RMB: Pull object"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.ViewModel = "models/weapons/v_pistol.mdl"
SWEP.WorldModel = "models/weapons/w_pistol.mdl"

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:PrimaryAttack()
    if not self:CanPrimaryAttack() then return end
    self:SetNextPrimaryFire(CurTime() + 1.0)
    
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    -- Трейс-выстрел
    local trace = util.TraceLine({
        start = owner:GetShootPos(),
        endpos = owner:GetShootPos() + owner:GetAimVector() * 5000,
        filter = owner
    })
    
    if trace.Hit then
        -- Звук выстрела гарпуна
        self:EmitSound("weapons/crossbow/fire1.wav")
        
        -- ВИЗУАЛЬНЫЙ ТРОС (эффект)
        local effect = EffectData()
        effect:SetStart(owner:GetShootPos())
        effect:SetOrigin(trace.HitPos)
        effect:SetEntity(self)
        effect:SetAttachment(1)
        util.Effect("ToolTracer", effect)
        
        -- УЛУЧШЕННОЕ ПРИТЯГИВАНИЕ - БЫСТРЕЕ НО БЕЗОПАСНО
        local pullDirection = (trace.HitPos - owner:GetPos()):GetNormalized()
        local currentVel = owner:GetVelocity()
        
        -- Увеличил скорость, но добавил ограничение по вертикали для безопасности
        local targetSpeed = 3000 -- Сильная скорость!
        local targetVel = pullDirection * targetSpeed
        
        -- Умное притягивание: сильнее по горизонтали, слабее по вертикали
        local safeVel = Vector(targetVel.x, targetVel.y, targetVel.z * 0.7)
        
        -- Плавное, но мощное ускорение
        owner:SetVelocity((safeVel - currentVel) * 0.5)
        
        -- Звук "зацепа"
        owner:EmitSound("weapons/crossbow/hit1.wav")
        
    else
        -- Промах - просто звук
        self:EmitSound("weapons/pistol/pistol_empty.wav")
    end
    
    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
end

function SWEP:SecondaryAttack()
    if not self:CanSecondaryAttack() then return end
    self:SetNextSecondaryFire(CurTime() + 0.5)
    
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    local trace = util.TraceLine({
        start = owner:GetShootPos(),
        endpos = owner:GetShootPos() + owner:GetAimVector() * 1000,
        filter = owner
    })
    
    if IsValid(trace.Entity) then
        local phys = trace.Entity:GetPhysicsObject()
        if IsValid(phys) then
            -- Притягиваем объект к игроку
            local dir = (owner:GetPos() - trace.Entity:GetPos()):GetNormalized()
            phys:SetVelocity(dir * 800) -- Увеличил силу притягивания объектов
            
            -- Звук притягивания объекта
            owner:EmitSound("physics/metal/metal_box_impact_bullet1.wav")
            
            -- Эффект троса к объекту
            local effect = EffectData()
            effect:SetStart(owner:GetShootPos())
            effect:SetOrigin(trace.HitPos)
            effect:SetEntity(self)
            util.Effect("ToolTracer", effect)
        else
            owner:ChatPrint("Cannot pull this object!")
        end
    else
        self:EmitSound("weapons/pistol/pistol_empty.wav")
    end
    
    self:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
end

function SWEP:CanPrimaryAttack()
    return true
end

function SWEP:CanSecondaryAttack()
    return true
end